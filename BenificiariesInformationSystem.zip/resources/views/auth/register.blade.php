<x-guest-layout>
    <livewire:register-user />
</x-guest-layout>
