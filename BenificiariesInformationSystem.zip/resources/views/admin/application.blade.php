@section('title', 'Application')
<x-admin-layout>
    <div>
        <livewire:admin.application-list />
    </div>
</x-admin-layout>
