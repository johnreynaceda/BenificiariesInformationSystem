@section('title', 'Approve Application')
<x-admin-layout>
    <div>
        <livewire:admin.approve-list />
    </div>


</x-admin-layout>
