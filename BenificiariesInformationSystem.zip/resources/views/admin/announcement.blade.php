@section('title', 'Announcement')
<x-admin-layout>
    <div>
        <livewire:announcement-list />
    </div>
</x-admin-layout>
