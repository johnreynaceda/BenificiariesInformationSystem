@section('title', 'Beneficiary Type')
<x-admin-layout>
    <div>
        <livewire:admin.beneficiary-list />
    </div>
</x-admin-layout>
