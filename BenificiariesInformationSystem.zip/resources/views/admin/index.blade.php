@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        sdsds
    </div>
</x-admin-layout>
