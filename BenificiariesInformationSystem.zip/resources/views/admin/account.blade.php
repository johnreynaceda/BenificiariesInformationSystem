@section('title', 'Accounts')
<x-admin-layout>
    <div>
        <livewire:admin.account-list />
    </div>
</x-admin-layout>
