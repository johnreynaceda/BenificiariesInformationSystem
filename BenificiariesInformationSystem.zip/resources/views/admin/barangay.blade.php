@section('title', 'Barangay')
<x-admin-layout>
    <div>
        <livewire:admin.barangay-list />
    </div>
</x-admin-layout>
