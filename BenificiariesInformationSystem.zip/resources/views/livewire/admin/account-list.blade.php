<div>
    {{ $this->table }}
</div>
