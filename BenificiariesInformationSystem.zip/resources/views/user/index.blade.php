<x-user-layout>
    <h1 class="text-3xl font-bold text-gray-700 text-center">OUR ASSISTANCE TO INDIVIDUAL IN CRISIS SITUATION
    </h1>
    <livewire:user.assistance-form />
</x-user-layout>
