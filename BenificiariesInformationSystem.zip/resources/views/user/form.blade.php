<x-user-layout>
    <div class="max-w-7xl mx-auto">
        <livewire:user.fill-out-form />
    </div>
</x-user-layout>
